#ifndef __TASK_H_INCLUDED__
#define __TASK_H_INCLUDED__

int SolveSystem(int n, double *a, double *b, double *x, int my_rank, int total_threads);

#endif /* __TASK_H_INCLUDED__ */
