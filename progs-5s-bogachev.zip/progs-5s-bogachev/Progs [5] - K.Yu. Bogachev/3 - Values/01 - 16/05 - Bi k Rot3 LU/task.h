#ifndef __TASK_H_INCLUDED__
#define __TASK_H_INCLUDED__

void FindValue(int n, double* a, int k, double* valueOut, double eps, int* iterOut);

#endif /* not __TASK_H_INCLUDED__ */
