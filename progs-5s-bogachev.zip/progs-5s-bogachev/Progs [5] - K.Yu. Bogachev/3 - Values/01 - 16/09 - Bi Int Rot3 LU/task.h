#ifndef __TASK_H_INCLUDED__
#define __TASK_H_INCLUDED__

void FindValues(int n, double* a, double left, double right, double* values, int* nValuesOut, double eps, int* iterOut);

#endif /* not __TASK_H_INCLUDED__ */
