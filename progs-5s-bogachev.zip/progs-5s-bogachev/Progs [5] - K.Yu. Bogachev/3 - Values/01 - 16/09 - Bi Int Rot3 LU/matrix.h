#ifndef __MATRIX_H_INCLUDED__
#define __MATRIX_H_INCLUDED__

int InputMatrix(int n, double* a, int inputMode, FILE* fin);

void PrintMatrix(int n, double* a);

void PrintVector(int n, double* a);

#endif /* not __MATRIX_H_INCLUDED__ */
