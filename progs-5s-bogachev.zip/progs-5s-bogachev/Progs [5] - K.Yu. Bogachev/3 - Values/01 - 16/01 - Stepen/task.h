#ifndef __TASK_H_INCLUDED__
#define __TASK_H_INCLUDED__

void FindValue(int n, double* a, double* valueOut, double* x1, double* x2, int* iterOut);

#endif /* not __TASK_H_INCLUDED__ */
