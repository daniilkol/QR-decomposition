#ifndef __TASK_H_INCLUDED__
#define __TASK_H_INCLUDED__

int FindValue(int n, double* a, double lambda, double eps, double* e, double* a1, double* x2, int* iterOut);

#endif /* not __TASK_H_INCLUDED__ */
