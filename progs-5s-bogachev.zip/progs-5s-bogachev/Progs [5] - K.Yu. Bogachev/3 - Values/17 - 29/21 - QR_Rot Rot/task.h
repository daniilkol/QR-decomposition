#ifndef __TASK_H_INCLUDED__
#define __TASK_H_INCLUDED__

void FindValues(int n, double* a, double* values, double eps, double* cosPhi, double* sinPhi, int* iterOut);

#endif /* not __TASK_H_INCLUDED__ */
