#ifndef __TASK_H_INCLUDED__
#define __TASK_H_INCLUDED__

int InvertMatrix(int n, double* a, double* x);

#endif /* not __TASK_H_INCLUDED__ */
