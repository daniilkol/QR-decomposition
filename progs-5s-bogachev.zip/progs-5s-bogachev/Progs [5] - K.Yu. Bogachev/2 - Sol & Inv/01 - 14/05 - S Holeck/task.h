#ifndef __TASK_H_INCLUDED__
#define __TASK_H_INCLUDED__

int SolveSystem(int n, double* a, double* b, double* x, double* d);

#endif /* not __TASK_H_INCLUDED__ */
