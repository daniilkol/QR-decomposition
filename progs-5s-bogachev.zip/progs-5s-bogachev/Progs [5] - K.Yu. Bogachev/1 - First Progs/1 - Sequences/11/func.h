#ifndef __FUNC_H_INCLUDED__
#define __FUNC_H_INCLUDED__ 1

int func(char* fname, double x);

#endif /* not __FUNC_H_INCLUDED__ */
