#ifndef __FUNC_H_INCLUDED__
#define __FUNC_H_INCLUDED__ 1

int func(char* fname1, char* fname2);

#endif /* not __FUNC_H_INCLUDED__ */
