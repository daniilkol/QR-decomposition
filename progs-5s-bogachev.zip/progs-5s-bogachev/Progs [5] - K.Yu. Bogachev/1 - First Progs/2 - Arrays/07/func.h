#ifndef __FUNC_H_INCLUDED__
#define __FUNC_H_INCLUDED__ 1

void func(int n, double* a, int k);

#endif /* not __FUNC_H_INCLUDED__ */
