#ifndef __FUNC_H_INCLUDED__
#define __FUNC_H_INCLUDED__ 1

int func(int n, double* a);

#endif /* not __FUNC_H_INCLUDED__ */
