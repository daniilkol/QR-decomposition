#ifndef __FUNC_H_INCLUDED__
#define __FUNC_H_INCLUDED__ 1

void func(int m, int n, double* a, int i, int j, double b);

#endif /* not __FUNC_H_INCLUDED__ */
